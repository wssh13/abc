#!/usr/bin/env bash
#panel路径
PanelPath="/jd/panel"
 
#判断panel文件夹是否存在，若不存在，则重新安装
if [[ ! -d "$PanelPath" ]]; then
 echo "控制面板不存在，重新安装面板"
 bash /jd/v4mb.sh
 echo "启动控制面板挂载程序..."
 pm2 start /jd/panel/server.js
else
 echo -e "检测面板是否运行"
 PROC_NAME=server.js
 ProcNumber=`ps -ef |grep -w $PROC_NAME|grep -v grep|wc -l`
 if [ $ProcNumber -le 0 ];then
   echo -e "面板进程没运行\n"
   pm2 start /jd/panel/server.js
 else
   echo -e "面板进程运行中\n"
 fi
fi